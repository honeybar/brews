<?php

/**
 * Test for @{class:ArcanistNoLintLinter}.
 *
 * Not a real test... meant to fail lint
 * if @nolint is not respected.
 *
 * @group testcase
 */
class ArcanistNoLintTestCaseMisnamed extends ArcanistLinterTestCase {

}
