<?php

/**
 * Thrown when no engine is configured for linting or running unit tests.
 *
 * @group workflow
 */
final class ArcanistNoEngineException extends ArcanistUsageException {
}
