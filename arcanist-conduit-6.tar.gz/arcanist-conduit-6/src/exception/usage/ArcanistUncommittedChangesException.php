<?php

final class ArcanistUncommittedChangesException extends ArcanistUsageException {

}
