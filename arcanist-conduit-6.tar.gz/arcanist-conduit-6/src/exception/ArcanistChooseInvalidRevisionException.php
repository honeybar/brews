<?php

/**
 * Thrown when the user chooses an invalid revision when prompted by a workflow.
 *
 * @group workflow
 */
final class ArcanistChooseInvalidRevisionException extends Exception {

}
