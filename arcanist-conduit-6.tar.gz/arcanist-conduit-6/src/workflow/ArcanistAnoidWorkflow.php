<?php

/**
 * @group workflow
 */
final class ArcanistAnoidWorkflow extends ArcanistBaseWorkflow {

  public function getWorkflowName() {
    return 'anoid';
  }

  public function getCommandSynopses() {
    return phutil_console_format(<<<EOTEXT
      **anoid**
EOTEXT
      );
  }

  public function getCommandHelp() {
    return phutil_console_format(<<<EOTEXT
          There's only one way to find out...
EOTEXT
      );
  }

  public function run() {
    phutil_passthru(
      dirname(phutil_get_library_root('arcanist')) . '/scripts/breakout.py'
    );
  }

}
