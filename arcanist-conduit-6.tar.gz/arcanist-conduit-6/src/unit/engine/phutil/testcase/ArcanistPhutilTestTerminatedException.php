<?php

/**
 * Thrown to prematurely end test execution.
 *
 * @group unitrun
 */
final class ArcanistPhutilTestTerminatedException extends Exception {}
