<?php

/**
 * Thrown to skip test execution.
 *
 * @group unitrun
 */
final class ArcanistPhutilTestSkippedException extends Exception {}
