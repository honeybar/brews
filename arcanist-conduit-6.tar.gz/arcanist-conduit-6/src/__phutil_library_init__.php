<?php

phutil_register_library('arcanist', __FILE__);
